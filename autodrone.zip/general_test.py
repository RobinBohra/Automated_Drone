import speech_recognition as sr
print(dir(sr))
